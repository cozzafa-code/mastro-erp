'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase-browser'
import Link from 'next/link'

export default function SignupPage() {
  const [step, setStep] = useState<1 | 2>(1)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [nomeAzienda, setNomeAzienda] = useState('')
  const [nomeReferente, setNomeReferente] = useState('')
  const [telefono, setTelefono] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const router = useRouter()

  const handleStepOne = (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)

    if (password !== confirmPassword) {
      setError('Le password non coincidono')
      return
    }

    if (password.length < 6) {
      setError('La password deve avere almeno 6 caratteri')
      return
    }

    setStep(2)
  }

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setLoading(true)

    if (!nomeAzienda.trim()) {
      setError('Inserisci il nome dell\'azienda')
      setLoading(false)
      return
    }

    const supabase = createClient()

    // 1. Sign up the user
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          nome_azienda: nomeAzienda.trim(),
          nome_referente: nomeReferente.trim(),
          telefono: telefono.trim(),
        },
        emailRedirectTo: `${window.location.origin}/auth/callback`,
      },
    })

    if (authError) {
      setError(
        authError.message === 'User already registered'
          ? 'Questa email è già registrata. Prova ad accedere.'
          : authError.message
      )
      setLoading(false)
      return
    }

    // 2. Create profile in profiles table
    if (authData.user) {
      const { error: profileError } = await supabase
        .from('profiles')
        .upsert({
          id: authData.user.id,
          email: email,
          nome_azienda: nomeAzienda.trim(),
          nome_referente: nomeReferente.trim(),
          telefono: telefono.trim(),
        })

      if (profileError) {
        console.error('Profile creation error:', profileError)
        // Don't block signup if profile creation fails
        // It can be retried on first login
      }
    }

    setSuccess(true)
    setLoading(false)
  }

  // Success screen
  if (success) {
    return (
      <div style={{
        minHeight: '100vh',
        backgroundColor: '#F2F1EC',
        display: 'flex',
        flexDirection: 'column',
        fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif",
      }}>
        <TopBar />
        <div style={{
          flex: 1,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '40px 20px',
        }}>
          <div style={{
            width: '100%',
            maxWidth: 440,
            textAlign: 'center',
          }}>
            <div style={{
              width: 64,
              height: 64,
              borderRadius: '50%',
              backgroundColor: '#D08008',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto 24px',
              fontSize: 28,
            }}>
              ✓
            </div>
            <h1 style={{
              fontSize: 24,
              fontWeight: 700,
              color: '#1A1A1C',
              margin: '0 0 12px',
            }}>
              Registrazione completata!
            </h1>
            <p style={{
              fontSize: 15,
              color: '#6B6B6B',
              margin: '0 0 32px',
              lineHeight: 1.6,
            }}>
              Controlla la tua email <strong style={{ color: '#1A1A1C' }}>{email}</strong> per 
              confermare l&apos;account. Dopo la conferma potrai accedere al tuo pannello MASTRO.
            </p>
            <Link
              href="/login"
              style={{
                display: 'inline-block',
                padding: '13px 32px',
                fontSize: 15,
                fontWeight: 600,
                color: '#FFFFFF',
                backgroundColor: '#D08008',
                borderRadius: 8,
                textDecoration: 'none',
                transition: 'background-color 0.15s',
              }}
            >
              Vai al Login
            </Link>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div style={{
      minHeight: '100vh',
      backgroundColor: '#F2F1EC',
      display: 'flex',
      flexDirection: 'column',
      fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif",
    }}>
      <TopBar />

      {/* Content */}
      <div style={{
        flex: 1,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '40px 20px',
      }}>
        <div style={{
          width: '100%',
          maxWidth: 440,
        }}>
          {/* Header */}
          <div style={{ marginBottom: 32 }}>
            <h1 style={{
              fontSize: 28,
              fontWeight: 700,
              color: '#1A1A1C',
              margin: 0,
              letterSpacing: '-0.02em',
            }}>
              Crea il tuo account
            </h1>
            <p style={{
              fontSize: 15,
              color: '#6B6B6B',
              margin: '8px 0 0 0',
            }}>
              {step === 1 ? 'Inizia con le credenziali' : 'Raccontaci della tua azienda'}
            </p>
          </div>

          {/* Step indicator */}
          <div style={{
            display: 'flex',
            gap: 8,
            marginBottom: 32,
          }}>
            <div style={{
              flex: 1,
              height: 3,
              borderRadius: 2,
              backgroundColor: '#D08008',
            }} />
            <div style={{
              flex: 1,
              height: 3,
              borderRadius: 2,
              backgroundColor: step === 2 ? '#D08008' : '#D4D4D4',
              transition: 'background-color 0.3s',
            }} />
          </div>

          {/* Error */}
          {error && (
            <div style={{
              padding: '12px 16px',
              backgroundColor: '#FEF2F2',
              border: '1px solid #FECACA',
              borderRadius: 8,
              marginBottom: 24,
              fontSize: 14,
              color: '#DC2626',
            }}>
              {error}
            </div>
          )}

          {/* Step 1: Credentials */}
          {step === 1 && (
            <form onSubmit={handleStepOne}>
              <InputField
                label="Email"
                type="email"
                value={email}
                onChange={setEmail}
                placeholder="mario@azienda.it"
                required
              />
              <InputField
                label="Password"
                type="password"
                value={password}
                onChange={setPassword}
                placeholder="Minimo 6 caratteri"
                required
                minLength={6}
              />
              <InputField
                label="Conferma Password"
                type="password"
                value={confirmPassword}
                onChange={setConfirmPassword}
                placeholder="Ripeti la password"
                required
                minLength={6}
                marginBottom={32}
              />

              <button
                type="submit"
                style={{
                  width: '100%',
                  padding: '13px 0',
                  fontSize: 15,
                  fontWeight: 600,
                  color: '#FFFFFF',
                  backgroundColor: '#D08008',
                  border: 'none',
                  borderRadius: 8,
                  cursor: 'pointer',
                  transition: 'all 0.15s',
                  fontFamily: 'inherit',
                }}
                onMouseEnter={(e) => (e.target as HTMLButtonElement).style.backgroundColor = '#B8860B'}
                onMouseLeave={(e) => (e.target as HTMLButtonElement).style.backgroundColor = '#D08008'}
              >
                Continua →
              </button>
            </form>
          )}

          {/* Step 2: Company Info */}
          {step === 2 && (
            <form onSubmit={handleSignup}>
              <InputField
                label="Nome Azienda"
                type="text"
                value={nomeAzienda}
                onChange={setNomeAzienda}
                placeholder="Es. Serramenti Rossi SRL"
                required
              />
              <InputField
                label="Nome Referente"
                type="text"
                value={nomeReferente}
                onChange={setNomeReferente}
                placeholder="Mario Rossi"
              />
              <InputField
                label="Telefono"
                type="tel"
                value={telefono}
                onChange={setTelefono}
                placeholder="+39 333 1234567"
                marginBottom={32}
              />

              <div style={{ display: 'flex', gap: 12 }}>
                <button
                  type="button"
                  onClick={() => { setStep(1); setError(null) }}
                  style={{
                    flex: '0 0 auto',
                    padding: '13px 20px',
                    fontSize: 15,
                    fontWeight: 600,
                    color: '#6B6B6B',
                    backgroundColor: 'transparent',
                    border: '1.5px solid #D4D4D4',
                    borderRadius: 8,
                    cursor: 'pointer',
                    transition: 'all 0.15s',
                    fontFamily: 'inherit',
                  }}
                >
                  ← Indietro
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  style={{
                    flex: 1,
                    padding: '13px 0',
                    fontSize: 15,
                    fontWeight: 600,
                    color: '#FFFFFF',
                    backgroundColor: loading ? '#B8860B' : '#D08008',
                    border: 'none',
                    borderRadius: 8,
                    cursor: loading ? 'not-allowed' : 'pointer',
                    transition: 'all 0.15s',
                    fontFamily: 'inherit',
                    opacity: loading ? 0.7 : 1,
                  }}
                >
                  {loading ? 'Registrazione...' : 'Crea Account'}
                </button>
              </div>
            </form>
          )}

          {/* Login link */}
          <div style={{
            textAlign: 'center',
            marginTop: 24,
            fontSize: 14,
            color: '#6B6B6B',
          }}>
            Hai già un account?{' '}
            <Link
              href="/login"
              style={{
                color: '#D08008',
                fontWeight: 600,
                textDecoration: 'none',
              }}
            >
              Accedi
            </Link>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div style={{
        textAlign: 'center',
        padding: '16px 0',
        fontSize: 12,
        color: '#9CA3AF',
      }}>
        MASTRO ERP — Il sistema operativo per serramentisti
      </div>
    </div>
  )
}

// ─── Shared Components ────────────────────────────────────────

function TopBar() {
  return (
    <div style={{
      height: 56,
      backgroundColor: '#1A1A1C',
      display: 'flex',
      alignItems: 'center',
      paddingLeft: 24,
    }}>
      <span style={{
        color: '#D08008',
        fontSize: 18,
        fontWeight: 700,
        fontFamily: "'JetBrains Mono', monospace",
        letterSpacing: '-0.02em',
      }}>
        MASTRO
      </span>
      <span style={{
        color: 'rgba(255,255,255,0.4)',
        fontSize: 14,
        marginLeft: 8,
        fontWeight: 400,
      }}>
        ERP
      </span>
    </div>
  )
}

function InputField({
  label,
  type,
  value,
  onChange,
  placeholder,
  required,
  minLength,
  marginBottom = 20,
}: {
  label: string
  type: string
  value: string
  onChange: (v: string) => void
  placeholder?: string
  required?: boolean
  minLength?: number
  marginBottom?: number
}) {
  return (
    <div style={{ marginBottom }}>
      <label style={{
        display: 'block',
        fontSize: 13,
        fontWeight: 600,
        color: '#1A1A1C',
        marginBottom: 6,
        letterSpacing: '0.01em',
      }}>
        {label}
      </label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        required={required}
        minLength={minLength}
        style={{
          width: '100%',
          padding: '12px 14px',
          fontSize: 15,
          border: '1.5px solid #D4D4D4',
          borderRadius: 8,
          backgroundColor: '#FFFFFF',
          color: '#1A1A1C',
          outline: 'none',
          transition: 'border-color 0.15s',
          boxSizing: 'border-box' as const,
          fontFamily: 'inherit',
        }}
        onFocus={(e) => e.target.style.borderColor = '#D08008'}
        onBlur={(e) => e.target.style.borderColor = '#D4D4D4'}
      />
    </div>
  )
}
