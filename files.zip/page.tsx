'use client'

import { useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { createClient } from '@/lib/supabase-browser'
import Link from 'next/link'

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const router = useRouter()
  const searchParams = useSearchParams()
  const redirect = searchParams.get('redirect') || '/dashboard'

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setLoading(true)

    const supabase = createClient()
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (error) {
      setError(
        error.message === 'Invalid login credentials'
          ? 'Email o password non corretti'
          : error.message
      )
      setLoading(false)
      return
    }

    router.push(redirect)
    router.refresh()
  }

  return (
    <div style={{
      minHeight: '100vh',
      backgroundColor: '#F2F1EC',
      display: 'flex',
      flexDirection: 'column',
      fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif",
    }}>
      {/* Top bar */}
      <div style={{
        height: 56,
        backgroundColor: '#1A1A1C',
        display: 'flex',
        alignItems: 'center',
        paddingLeft: 24,
      }}>
        <span style={{
          color: '#D08008',
          fontSize: 18,
          fontWeight: 700,
          fontFamily: "'JetBrains Mono', monospace",
          letterSpacing: '-0.02em',
        }}>
          MASTRO
        </span>
        <span style={{
          color: 'rgba(255,255,255,0.4)',
          fontSize: 14,
          marginLeft: 8,
          fontWeight: 400,
        }}>
          ERP
        </span>
      </div>

      {/* Content */}
      <div style={{
        flex: 1,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '40px 20px',
      }}>
        <div style={{
          width: '100%',
          maxWidth: 400,
        }}>
          {/* Header */}
          <div style={{ marginBottom: 40 }}>
            <h1 style={{
              fontSize: 28,
              fontWeight: 700,
              color: '#1A1A1C',
              margin: 0,
              letterSpacing: '-0.02em',
            }}>
              Accedi
            </h1>
            <p style={{
              fontSize: 15,
              color: '#6B6B6B',
              margin: '8px 0 0 0',
            }}>
              Entra nel tuo pannello MASTRO
            </p>
          </div>

          {/* Error */}
          {error && (
            <div style={{
              padding: '12px 16px',
              backgroundColor: '#FEF2F2',
              border: '1px solid #FECACA',
              borderRadius: 8,
              marginBottom: 24,
              fontSize: 14,
              color: '#DC2626',
            }}>
              {error}
            </div>
          )}

          {/* Callback error */}
          {searchParams.get('error') === 'auth_callback_failed' && (
            <div style={{
              padding: '12px 16px',
              backgroundColor: '#FEF2F2',
              border: '1px solid #FECACA',
              borderRadius: 8,
              marginBottom: 24,
              fontSize: 14,
              color: '#DC2626',
            }}>
              Errore durante la verifica. Riprova.
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleLogin}>
            {/* Email */}
            <div style={{ marginBottom: 20 }}>
              <label style={{
                display: 'block',
                fontSize: 13,
                fontWeight: 600,
                color: '#1A1A1C',
                marginBottom: 6,
                letterSpacing: '0.01em',
              }}>
                Email
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="mario@azienda.it"
                required
                style={{
                  width: '100%',
                  padding: '12px 14px',
                  fontSize: 15,
                  border: '1.5px solid #D4D4D4',
                  borderRadius: 8,
                  backgroundColor: '#FFFFFF',
                  color: '#1A1A1C',
                  outline: 'none',
                  transition: 'border-color 0.15s',
                  boxSizing: 'border-box',
                  fontFamily: 'inherit',
                }}
                onFocus={(e) => e.target.style.borderColor = '#D08008'}
                onBlur={(e) => e.target.style.borderColor = '#D4D4D4'}
              />
            </div>

            {/* Password */}
            <div style={{ marginBottom: 32 }}>
              <label style={{
                display: 'block',
                fontSize: 13,
                fontWeight: 600,
                color: '#1A1A1C',
                marginBottom: 6,
                letterSpacing: '0.01em',
              }}>
                Password
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                minLength={6}
                style={{
                  width: '100%',
                  padding: '12px 14px',
                  fontSize: 15,
                  border: '1.5px solid #D4D4D4',
                  borderRadius: 8,
                  backgroundColor: '#FFFFFF',
                  color: '#1A1A1C',
                  outline: 'none',
                  transition: 'border-color 0.15s',
                  boxSizing: 'border-box',
                  fontFamily: 'inherit',
                }}
                onFocus={(e) => e.target.style.borderColor = '#D08008'}
                onBlur={(e) => e.target.style.borderColor = '#D4D4D4'}
              />
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              style={{
                width: '100%',
                padding: '13px 0',
                fontSize: 15,
                fontWeight: 600,
                color: '#FFFFFF',
                backgroundColor: loading ? '#B8860B' : '#D08008',
                border: 'none',
                borderRadius: 8,
                cursor: loading ? 'not-allowed' : 'pointer',
                transition: 'all 0.15s',
                fontFamily: 'inherit',
                letterSpacing: '0.01em',
                opacity: loading ? 0.7 : 1,
              }}
              onMouseEnter={(e) => {
                if (!loading) (e.target as HTMLButtonElement).style.backgroundColor = '#B8860B'
              }}
              onMouseLeave={(e) => {
                if (!loading) (e.target as HTMLButtonElement).style.backgroundColor = '#D08008'
              }}
            >
              {loading ? 'Accesso in corso...' : 'Accedi'}
            </button>
          </form>

          {/* Signup link */}
          <div style={{
            textAlign: 'center',
            marginTop: 24,
            fontSize: 14,
            color: '#6B6B6B',
          }}>
            Non hai un account?{' '}
            <Link
              href="/signup"
              style={{
                color: '#D08008',
                fontWeight: 600,
                textDecoration: 'none',
              }}
            >
              Registrati
            </Link>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div style={{
        textAlign: 'center',
        padding: '16px 0',
        fontSize: 12,
        color: '#9CA3AF',
      }}>
        MASTRO ERP — Il sistema operativo per serramentisti
      </div>
    </div>
  )
}
