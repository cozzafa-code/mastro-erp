# MASTRO ERP — Giorno 2: Auth + Registrazione

## 📦 File creati

```
├── middleware.ts                          # Protegge /dashboard, redirect → /login
├── lib/
│   ├── supabase-browser.ts               # Client Supabase per componenti client
│   ├── supabase-server.ts                # Client Supabase per server components
│   └── hooks/useAuth.ts                  # Hook React: user, profile, signOut
├── app/
│   ├── login/page.tsx                    # Pagina login
│   ├── signup/page.tsx                   # Pagina registrazione (2 step)
│   └── auth/callback/route.ts           # Callback conferma email
└── supabase/migrations/
    └── 20250225_001_auth_profiles.sql    # Tabella profiles + RLS + triggers
```

## 🚀 Setup veloce

### 1. Installa dipendenza
```bash
npm install @supabase/ssr
```
> Nota: `@supabase/supabase-js` dovrebbe già essere installato

### 2. Verifica .env.local
```env
NEXT_PUBLIC_SUPABASE_URL=https://xxxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGci...
```

### 3. Esegui la migration SQL
Vai su **Supabase Dashboard → SQL Editor** e incolla il contenuto di:
`supabase/migrations/20250225_001_auth_profiles.sql`

### 4. Abilita Email Auth su Supabase
- Dashboard → Authentication → Providers → Email → **Enable**
- Per dev locale: disabilita "Confirm email" per testare più veloce

### 5. Copia i file nel repo
```bash
# Dalla root del progetto
cp middleware.ts ./
cp -r lib/ ./
cp -r app/login app/signup app/auth ./app/
```

## 🔧 Integrazione con MastroERP.tsx

Aggiungi il bottone logout nella topbar del componente esistente:

```tsx
import { useAuth } from '@/lib/hooks/useAuth'

// Dentro MastroERP component:
const { user, profile, signOut } = useAuth()

// Nella topbar, accanto al logo:
<div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
  <span style={{ color: '#9CA3AF', fontSize: 13 }}>
    {profile?.nome_azienda || user?.email}
  </span>
  <button onClick={signOut} style={{
    padding: '6px 12px',
    fontSize: 12,
    color: '#9CA3AF',
    backgroundColor: 'transparent',
    border: '1px solid rgba(255,255,255,0.1)',
    borderRadius: 6,
    cursor: 'pointer',
  }}>
    Esci
  </button>
</div>
```

## 🔒 Come funziona

1. **Middleware** intercetta ogni request:
   - Se NON autenticato → redirect a `/login`
   - Se autenticato e va su `/login` → redirect a `/dashboard`
   - Rinnova automaticamente la sessione via cookie

2. **Signup** (2 step):
   - Step 1: Email + Password
   - Step 2: Nome Azienda + Referente + Telefono
   - Crea utente in `auth.users` + profilo in `profiles` (doppio: client + trigger DB)

3. **Profiles table** con RLS:
   - Ogni utente vede solo il proprio profilo
   - Trigger auto-create alla registrazione
   - Campi: piano (free/pro/enterprise), ruolo (admin/operatore/viewer)

## ✅ Test checklist

- [ ] `/login` visibile senza auth
- [ ] `/signup` → registrazione 2 step funzionante
- [ ] Dopo signup → email di conferma ricevuta
- [ ] Dopo login → redirect a `/dashboard`
- [ ] `/dashboard` protetto (redirect a `/login` se non autenticato)
- [ ] Profilo creato in tabella `profiles`
- [ ] Logout funzionante
- [ ] Refresh pagina mantiene la sessione
