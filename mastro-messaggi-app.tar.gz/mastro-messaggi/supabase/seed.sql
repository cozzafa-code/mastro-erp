-- ============================================================
-- SEED DATA — Walter Cozza Serramenti SRL
-- Esegui DOPO schema.sql
-- ============================================================

-- Azienda
insert into azienda (id, nome, ragione_sociale, piva, indirizzo, tel, email)
values (
  '00000000-0000-0000-0000-000000000001',
  'Walter Cozza Serramenti',
  'Walter Cozza Serramenti SRL',
  'IT01234567890',
  'Cosenza (CS)',
  '+39 0984 123456',
  'info@cozzaserramenti.it'
);

-- Team Members
insert into team_members (id, azienda_id, nome, ruolo, colore, iniziali, email, tel, ordine) values
  ('10000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000001', 'Fabio Cozza', 'Titolare', '#1A1C1E', 'FC', 'fabio@cozzaserramenti.it', '+39 333 0000001', 0),
  ('10000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-000000000001', 'Roberto M.', 'Preventivista', '#AF52DE', 'RM', 'roberto@cozzaserramenti.it', '+39 333 0000002', 1),
  ('10000000-0000-0000-0000-000000000003', '00000000-0000-0000-0000-000000000001', 'Francesca L.', 'Amministrazione', '#FF2D55', 'FL', 'francesca@cozzaserramenti.it', '+39 333 0000003', 2),
  ('10000000-0000-0000-0000-000000000004', '00000000-0000-0000-0000-000000000001', 'Antonio P.', 'Acquisti', '#FF9500', 'AP', 'antonio@cozzaserramenti.it', '+39 333 0000004', 3),
  ('10000000-0000-0000-0000-000000000005', '00000000-0000-0000-0000-000000000001', 'Giuseppe T.', 'Magazziniere', '#5AC8FA', 'GT', 'giuseppe@cozzaserramenti.it', '+39 333 0000005', 4),
  ('10000000-0000-0000-0000-000000000006', '00000000-0000-0000-0000-000000000001', 'Marco D.', 'Produzione', '#34C759', 'MD', 'marco@cozzaserramenti.it', '+39 333 0000006', 5),
  ('10000000-0000-0000-0000-000000000007', '00000000-0000-0000-0000-000000000001', 'Pino G.', 'Capo montatore', '#007AFF', 'PG', 'pino@cozzaserramenti.it', '+39 333 0000007', 6);

-- Rappresentanti
insert into rappresentanti (id, azienda_id, nome, zona, tel, email, colore, iniziali, provvigione) values
  ('20000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000001', 'Luca Ferraro', 'Cosenza Centro', '+39 345 1112233', 'luca.f@gmail.com', '#E8590C', 'LF', 5.00),
  ('20000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-000000000001', 'Salvatore Mancini', 'Rende / Unical', '+39 338 4455667', 's.mancini@libero.it', '#0EA5E9', 'SM', 6.00),
  ('20000000-0000-0000-0000-000000000003', '00000000-0000-0000-0000-000000000001', 'Teresa Bruno', 'Crotone / Cirò', '+39 320 9988776', 'teresa.b@virgilio.it', '#D946EF', 'TB', 5.00);

-- Fasi Workflow (11 fasi)
insert into fasi (id, azienda_id, slug, label, icona, colore, responsabile_default, azione, dest, ordine) values
  ('30000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000001', 'misure', 'Misure', '📐', '#FF3B30', '10000000-0000-0000-0000-000000000001', 'Misure completate → Preventivista', 'preventivista', 0),
  ('30000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-000000000001', 'preventivo', 'Preventivo', '📋', '#FF9500', '10000000-0000-0000-0000-000000000002', 'Preventivo inviato → Attesa', 'cliente', 1),
  ('30000000-0000-0000-0000-000000000003', '00000000-0000-0000-0000-000000000001', 'attesa_cliente', 'Attesa cliente', '⏳', '#8E8E93', '10000000-0000-0000-0000-000000000002', 'Cliente conferma → Ordine', 'preventivista', 2),
  ('30000000-0000-0000-0000-000000000004', '00000000-0000-0000-0000-000000000001', 'conferma_ordine', 'Conferma ordine', '✅', '#34C759', '10000000-0000-0000-0000-000000000002', 'Ordine confermato → Fattura', 'amministrazione', 3),
  ('30000000-0000-0000-0000-000000000005', '00000000-0000-0000-0000-000000000001', 'fattura_acconto', 'Fattura acconto', '🧾', '#FF2D55', '10000000-0000-0000-0000-000000000003', 'Fattura emessa → Pagamento', 'amministrazione', 4),
  ('30000000-0000-0000-0000-000000000006', '00000000-0000-0000-0000-000000000001', 'pagamento_acconto', 'Pagamento', '💳', '#34C759', '10000000-0000-0000-0000-000000000003', 'Pagamento OK → Ordina materiali', 'acquisti', 5),
  ('30000000-0000-0000-0000-000000000007', '00000000-0000-0000-0000-000000000001', 'ordine_materiali', 'Ordine materiali', '📦', '#AF52DE', '10000000-0000-0000-0000-000000000004', 'Materiali ordinati → Attesa', 'magazzino', 6),
  ('30000000-0000-0000-0000-000000000008', '00000000-0000-0000-0000-000000000001', 'attesa_materiali', 'Attesa materiali', '🏭', '#5AC8FA', '10000000-0000-0000-0000-000000000005', 'Materiali arrivati → Produzione', 'produzione', 7),
  ('30000000-0000-0000-0000-000000000009', '00000000-0000-0000-0000-000000000001', 'produzione', 'Produzione', '🔧', '#EAB308', '10000000-0000-0000-0000-000000000006', 'Produzione completata → Montaggio', 'montatore', 8),
  ('30000000-0000-0000-0000-000000000010', '00000000-0000-0000-0000-000000000001', 'montaggio', 'Montaggio', '🏗️', '#007AFF', '10000000-0000-0000-0000-000000000007', 'Montaggio completato → Chiusura', 'titolare', 9),
  ('30000000-0000-0000-0000-000000000011', '00000000-0000-0000-0000-000000000001', 'chiusura', 'Chiusura cantiere', '🏁', '#34C759', '10000000-0000-0000-0000-000000000001', 'Cantiere chiuso', null, 10);

-- Sotto-fasi Produzione (12)
insert into fase_sotto_fasi (fase_id, slug, label, icona, note, ordine) values
  ('30000000-0000-0000-0000-000000000009', 'prelievo', 'Prelievo materiale da magazzino', '📦', 'Verifica DDT e quantità', 0),
  ('30000000-0000-0000-0000-000000000009', 'taglio', 'Taglio profili', '✂️', 'Tolleranza ±0.5mm', 1),
  ('30000000-0000-0000-0000-000000000009', 'cnc', 'Lavorazioni CNC', '🔩', 'Fori drenaggio, cerniere, maniglie', 2),
  ('30000000-0000-0000-0000-000000000009', 'rinforzi', 'Inserimento rinforzi acciaio', '🔗', 'Verifica lunghezza e fissaggio', 3),
  ('30000000-0000-0000-0000-000000000009', 'saldatura', 'Saldatura angoli', '🔥', '4 angoli per anta, verifica allineamento', 4),
  ('30000000-0000-0000-0000-000000000009', 'pulizia', 'Pulizia saldature', '🧹', 'Rimuovere bave, controllare estetica', 5),
  ('30000000-0000-0000-0000-000000000009', 'ferramenta', 'Montaggio ferramenta', '🔧', 'Cerniere, maniglie, cremonesi, limitatori', 6),
  ('30000000-0000-0000-0000-000000000009', 'guarnizioni', 'Applicazione guarnizioni', '🔘', 'Guarnizioni TPE, verifica continuità', 7),
  ('30000000-0000-0000-0000-000000000009', 'vetro', 'Inserimento vetrocamera', '🪟', 'Zeppe, sigillatura, verifica Ug', 8),
  ('30000000-0000-0000-0000-000000000009', 'regolazione', 'Regolazione apertura/chiusura', '⚙️', 'Test funzionale completo', 9),
  ('30000000-0000-0000-0000-000000000009', 'qc', 'Controllo qualità finale', '✅', 'Estetica, funzionamento, misure finali', 10),
  ('30000000-0000-0000-0000-000000000009', 'imballo', 'Etichettatura e imballo', '🏷️', 'Etichetta CM + vano, protezione trasporto', 11);

-- Sotto-fasi Montaggio (12)
insert into fase_sotto_fasi (fase_id, slug, label, icona, note, ordine) values
  ('30000000-0000-0000-0000-000000000010', 'carico', 'Carico mezzi e materiale', '🚛', 'Verifica lista carico vs commessa', 0),
  ('30000000-0000-0000-0000-000000000010', 'arrivo', 'Arrivo in cantiere e setup', '📍', 'Teli protettivi, utensili, DPI', 1),
  ('30000000-0000-0000-0000-000000000010', 'rimozione', 'Rimozione vecchi serramenti', '🔨', 'Attenzione intonaco e soglie', 2),
  ('30000000-0000-0000-0000-000000000010', 'preparazione', 'Preparazione vano', '📏', 'Pulizia, livellamento, verifica misure', 3),
  ('30000000-0000-0000-0000-000000000010', 'controtelaio', 'Posa controtelaio', '🔩', 'Fischer, livella, squadra', 4),
  ('30000000-0000-0000-0000-000000000010', 'posa', 'Montaggio serramenti', '🪟', 'Inserimento, fissaggio, centratura', 5),
  ('30000000-0000-0000-0000-000000000010', 'sigillatura', 'Sigillatura e schiuma', '🔧', 'Schiuma PU, silicone, nastro autoespandente', 6),
  ('30000000-0000-0000-0000-000000000010', 'regolazione', 'Regolazione e test', '⚙️', 'Apertura, chiusura, tenuta', 7),
  ('30000000-0000-0000-0000-000000000010', 'finiture', 'Finiture e coprifili', '✨', 'Coprifili, silicone finitura, puliture', 8),
  ('30000000-0000-0000-0000-000000000010', 'pulizia_cantiere', 'Pulizia cantiere', '🧹', 'Rimozione teli, pulizia vetri e profili', 9),
  ('30000000-0000-0000-0000-000000000010', 'foto', 'Foto prima/dopo', '📸', 'Documentazione per archivio e ENEA', 10),
  ('30000000-0000-0000-0000-000000000010', 'firma', 'Verifica e firma cliente', '✍️', 'Controllo congiunto, firma accettazione', 11);

-- Checklist per fasi principali
insert into fase_checklist (fase_id, testo, ordine) values
  ('30000000-0000-0000-0000-000000000001', 'Misure vani prese', 0),
  ('30000000-0000-0000-0000-000000000001', 'Foto vani scattate', 1),
  ('30000000-0000-0000-0000-000000000001', 'Cassonetti verificati', 2),
  ('30000000-0000-0000-0000-000000000001', 'Spallette misurate', 3),
  ('30000000-0000-0000-0000-000000000001', 'Soglie controllate', 4),
  ('30000000-0000-0000-0000-000000000001', 'Scheda misure compilata', 5),
  ('30000000-0000-0000-0000-000000000002', 'Configurazione sistema scelta', 0),
  ('30000000-0000-0000-0000-000000000002', 'Calcolo prezzi completato', 1),
  ('30000000-0000-0000-0000-000000000002', 'PDF preventivo generato', 2),
  ('30000000-0000-0000-0000-000000000002', 'Preventivo inviato al cliente', 3),
  ('30000000-0000-0000-0000-000000000009', 'Materiale prelevato da magazzino', 0),
  ('30000000-0000-0000-0000-000000000009', 'Taglio profili completato', 1),
  ('30000000-0000-0000-0000-000000000009', 'Saldature eseguite', 2),
  ('30000000-0000-0000-0000-000000000009', 'Ferramenta montata', 3),
  ('30000000-0000-0000-0000-000000000009', 'Vetri inseriti', 4),
  ('30000000-0000-0000-0000-000000000009', 'Controllo qualità superato', 5),
  ('30000000-0000-0000-0000-000000000009', 'Imballo e etichettatura', 6),
  ('30000000-0000-0000-0000-000000000010', 'Carico mezzo completato', 0),
  ('30000000-0000-0000-0000-000000000010', 'Vecchi serramenti rimossi', 1),
  ('30000000-0000-0000-0000-000000000010', 'Nuovi serramenti posati', 2),
  ('30000000-0000-0000-0000-000000000010', 'Sigillatura completata', 3),
  ('30000000-0000-0000-0000-000000000010', 'Test funzionale OK', 4),
  ('30000000-0000-0000-0000-000000000010', 'Foto prima/dopo fatte', 5),
  ('30000000-0000-0000-0000-000000000010', 'Firma cliente ottenuta', 6),
  ('30000000-0000-0000-0000-000000000011', 'Pratica ENEA compilata', 0),
  ('30000000-0000-0000-0000-000000000011', 'Fattura saldo emessa', 1),
  ('30000000-0000-0000-0000-000000000011', 'Pagamento saldo ricevuto', 2),
  ('30000000-0000-0000-0000-000000000011', 'Garanzia generata', 3),
  ('30000000-0000-0000-0000-000000000011', 'Fascicolo archiviato', 4);
