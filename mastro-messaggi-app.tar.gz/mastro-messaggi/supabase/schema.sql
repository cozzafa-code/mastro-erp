-- ============================================================
-- MASTRO MESSAGGI — Schema Supabase
-- Copia e incolla nel SQL Editor di Supabase
-- ============================================================

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- ============================================================
-- ENUM TYPES
-- ============================================================
create type sorgente_tipo as enum ('rappresentante', 'misure', 'diretto');
create type blocco_tipo as enum ('materiale', 'pagamento', 'cliente', 'produzione', 'altro');
create type notifica_tipo as enum ('fase', 'blocco', 'rete', 'pagamento', 'preventivo', 'timer', 'commessa');
create type evento_tipo as enum ('produzione', 'posa', 'consegna', 'attesa', 'controllo', 'sopralluogo');

-- ============================================================
-- AZIENDA
-- ============================================================
create table azienda (
  id uuid primary key default uuid_generate_v4(),
  nome text not null,
  ragione_sociale text,
  piva text,
  indirizzo text,
  tel text,
  email text,
  pec text,
  logo_url text,
  created_at timestamptz default now()
);

-- ============================================================
-- TEAM MEMBERS (operatori interni)
-- ============================================================
create table team_members (
  id uuid primary key default uuid_generate_v4(),
  azienda_id uuid references azienda(id) on delete cascade,
  auth_user_id uuid references auth.users(id),
  nome text not null,
  ruolo text not null,
  colore text default '#007AFF',
  iniziali text not null,
  email text,
  tel text,
  attivo boolean default true,
  ordine int default 0,
  created_at timestamptz default now()
);

-- ============================================================
-- RAPPRESENTANTI (rete commerciale)
-- ============================================================
create table rappresentanti (
  id uuid primary key default uuid_generate_v4(),
  azienda_id uuid references azienda(id) on delete cascade,
  auth_user_id uuid references auth.users(id),
  nome text not null,
  zona text,
  tel text,
  email text,
  colore text default '#E8590C',
  iniziali text not null,
  provvigione numeric(5,2) default 5.00,
  attivo boolean default true,
  created_at timestamptz default now()
);

-- ============================================================
-- FASI WORKFLOW (configurabili per azienda)
-- ============================================================
create table fasi (
  id uuid primary key default uuid_generate_v4(),
  azienda_id uuid references azienda(id) on delete cascade,
  slug text not null, -- 'misure', 'preventivo', etc.
  label text not null,
  icona text default '📋',
  colore text default '#007AFF',
  responsabile_default uuid references team_members(id),
  azione text, -- 'Misure completate → Preventivista'
  dest text, -- ruolo destinatario
  ordine int not null,
  attiva boolean default true,
  created_at timestamptz default now(),
  unique(azienda_id, slug)
);

create table fase_checklist (
  id uuid primary key default uuid_generate_v4(),
  fase_id uuid references fasi(id) on delete cascade,
  testo text not null,
  ordine int default 0
);

create table fase_sotto_fasi (
  id uuid primary key default uuid_generate_v4(),
  fase_id uuid references fasi(id) on delete cascade,
  slug text not null,
  label text not null,
  icona text default '📋',
  note text,
  ordine int default 0
);

create table fase_doc_richiesti (
  id uuid primary key default uuid_generate_v4(),
  fase_id uuid references fasi(id) on delete cascade,
  nome text not null
);

create table fase_doc_prodotti (
  id uuid primary key default uuid_generate_v4(),
  fase_id uuid references fasi(id) on delete cascade,
  nome text not null
);

-- ============================================================
-- COMMESSE
-- ============================================================
create table commesse (
  id uuid primary key default uuid_generate_v4(),
  azienda_id uuid references azienda(id) on delete cascade,
  codice text not null, -- 'CM-0001'
  cliente text not null,
  indirizzo text,
  tel text,
  email_cliente text,
  sorgente sorgente_tipo default 'diretto',
  rappresentante_id uuid references rappresentanti(id),
  provvigione_perc numeric(5,2) default 0,
  fase_corrente_id uuid references fasi(id),
  fase_idx int default 0,
  importo numeric(12,2) default 0,
  data_prevista date,
  note text,
  -- Blocco
  blocco_attivo boolean default false,
  blocco_motivo text,
  blocco_data timestamptz,
  blocco_da uuid references team_members(id),
  blocco_tipo blocco_tipo,
  -- Meta
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  archiviata boolean default false
);

-- Auto-increment codice
create or replace function generate_codice()
returns trigger as $$
declare
  next_num int;
begin
  select coalesce(max(cast(substring(codice from 4) as int)), 0) + 1
  into next_num
  from commesse
  where azienda_id = NEW.azienda_id;
  NEW.codice := 'CM-' || lpad(next_num::text, 4, '0');
  return NEW;
end;
$$ language plpgsql;

create trigger set_codice
  before insert on commesse
  for each row
  when (NEW.codice is null or NEW.codice = '')
  execute function generate_codice();

-- Auto-update updated_at
create or replace function update_updated_at()
returns trigger as $$
begin
  NEW.updated_at = now();
  return NEW;
end;
$$ language plpgsql;

create trigger set_updated_at
  before update on commesse
  for each row
  execute function update_updated_at();

-- ============================================================
-- COMMESSA VANI
-- ============================================================
create table commessa_vani (
  id uuid primary key default uuid_generate_v4(),
  commessa_id uuid references commesse(id) on delete cascade,
  descrizione text not null,
  larghezza int, -- mm
  altezza int,   -- mm
  tipo text,     -- 'finestra', 'portafinestra', 'scorrevole', etc.
  ordine int default 0
);

-- ============================================================
-- COMMESSA LOG (passaggi di fase — il cuore del sistema)
-- ============================================================
create table commessa_log (
  id uuid primary key default uuid_generate_v4(),
  commessa_id uuid references commesse(id) on delete cascade,
  fase_id uuid references fasi(id),
  da uuid references team_members(id),
  a uuid references team_members(id),
  messaggio text,
  tipo text default 'avanzamento', -- 'avanzamento', 'ritorno', 'blocco', 'sblocco'
  created_at timestamptz default now()
);

create table commessa_log_docs (
  id uuid primary key default uuid_generate_v4(),
  log_id uuid references commessa_log(id) on delete cascade,
  nome text not null,
  url text not null, -- Supabase Storage URL
  tipo_file text,    -- 'pdf', 'image', 'zip'
  size_bytes bigint
);

-- ============================================================
-- CHAT COMMESSA (messaggi real-time)
-- ============================================================
create table commessa_chat (
  id uuid primary key default uuid_generate_v4(),
  commessa_id uuid references commesse(id) on delete cascade,
  da uuid references team_members(id) not null,
  testo text not null,
  tipo text default 'messaggio', -- 'messaggio', 'stato', 'blocco', 'sistema'
  -- Allegati
  allegato_url text,
  allegato_nome text,
  allegato_tipo text,
  created_at timestamptz default now()
);

-- ============================================================
-- TIMER ENTRIES (tracciamento tempo)
-- ============================================================
create table timer_entries (
  id uuid primary key default uuid_generate_v4(),
  commessa_id uuid references commesse(id) on delete cascade,
  fase_id uuid references fasi(id),
  sotto_fase_id uuid references fase_sotto_fasi(id),
  membro_id uuid references team_members(id) not null,
  started_at timestamptz not null,
  stopped_at timestamptz,
  durata_secondi int, -- calcolato allo stop
  note text,
  created_at timestamptz default now()
);

-- ============================================================
-- CHECKLIST PROGRESS (avanzamento per commessa)
-- ============================================================
create table checklist_progress (
  id uuid primary key default uuid_generate_v4(),
  commessa_id uuid references commesse(id) on delete cascade,
  fase_checklist_id uuid references fase_checklist(id) on delete cascade,
  completato boolean default false,
  completato_da uuid references team_members(id),
  completato_at timestamptz,
  unique(commessa_id, fase_checklist_id)
);

-- ============================================================
-- EVENTI CALENDARIO
-- ============================================================
create table eventi (
  id uuid primary key default uuid_generate_v4(),
  azienda_id uuid references azienda(id) on delete cascade,
  commessa_id uuid references commesse(id),
  membro_id uuid references team_members(id),
  titolo text not null,
  tipo evento_tipo default 'produzione',
  data date not null,
  ora time,
  durata_minuti int default 60,
  note text,
  created_at timestamptz default now()
);

-- ============================================================
-- NOTIFICHE
-- ============================================================
create table notifiche (
  id uuid primary key default uuid_generate_v4(),
  azienda_id uuid references azienda(id) on delete cascade,
  destinatario_id uuid references team_members(id),
  rappresentante_id uuid references rappresentanti(id),
  commessa_id uuid references commesse(id),
  tipo notifica_tipo default 'fase',
  messaggio text not null,
  letto boolean default false,
  created_at timestamptz default now()
);

-- ============================================================
-- INDEXES for performance
-- ============================================================
create index idx_commesse_azienda on commesse(azienda_id);
create index idx_commesse_fase on commesse(fase_idx);
create index idx_commesse_rappresentante on commesse(rappresentante_id);
create index idx_commesse_blocco on commesse(blocco_attivo) where blocco_attivo = true;
create index idx_commessa_chat_commessa on commessa_chat(commessa_id);
create index idx_commessa_chat_created on commessa_chat(created_at desc);
create index idx_commessa_log_commessa on commessa_log(commessa_id);
create index idx_timer_entries_commessa on timer_entries(commessa_id);
create index idx_timer_entries_membro on timer_entries(membro_id);
create index idx_notifiche_dest on notifiche(destinatario_id) where letto = false;
create index idx_notifiche_repr on notifiche(rappresentante_id) where letto = false;
create index idx_eventi_data on eventi(data);

-- ============================================================
-- ROW LEVEL SECURITY (RLS)
-- ============================================================
alter table azienda enable row level security;
alter table team_members enable row level security;
alter table rappresentanti enable row level security;
alter table fasi enable row level security;
alter table commesse enable row level security;
alter table commessa_vani enable row level security;
alter table commessa_log enable row level security;
alter table commessa_log_docs enable row level security;
alter table commessa_chat enable row level security;
alter table timer_entries enable row level security;
alter table checklist_progress enable row level security;
alter table eventi enable row level security;
alter table notifiche enable row level security;

-- Helper: get user's azienda_id
create or replace function get_my_azienda_id()
returns uuid as $$
  select azienda_id from team_members where auth_user_id = auth.uid() limit 1;
$$ language sql security definer stable;

-- Policy: team members see their own azienda
create policy "Team sees own azienda" on team_members
  for all using (azienda_id = get_my_azienda_id());

create policy "Commesse own azienda" on commesse
  for all using (azienda_id = get_my_azienda_id());

create policy "Chat own azienda" on commessa_chat
  for all using (commessa_id in (select id from commesse where azienda_id = get_my_azienda_id()));

create policy "Fasi own azienda" on fasi
  for all using (azienda_id = get_my_azienda_id());

create policy "Notifiche own" on notifiche
  for all using (azienda_id = get_my_azienda_id());

create policy "Eventi own azienda" on eventi
  for all using (azienda_id = get_my_azienda_id());

create policy "Rappresentanti own azienda" on rappresentanti
  for all using (azienda_id = get_my_azienda_id());

create policy "Timer own azienda" on timer_entries
  for all using (commessa_id in (select id from commesse where azienda_id = get_my_azienda_id()));

create policy "Checklist own azienda" on checklist_progress
  for all using (commessa_id in (select id from commesse where azienda_id = get_my_azienda_id()));

create policy "Vani own azienda" on commessa_vani
  for all using (commessa_id in (select id from commesse where azienda_id = get_my_azienda_id()));

create policy "Log own azienda" on commessa_log
  for all using (commessa_id in (select id from commesse where azienda_id = get_my_azienda_id()));

create policy "Log docs own azienda" on commessa_log_docs
  for all using (log_id in (select id from commessa_log where commessa_id in (select id from commesse where azienda_id = get_my_azienda_id())));

-- ============================================================
-- REALTIME (enable for chat and commesse)
-- ============================================================
alter publication supabase_realtime add table commessa_chat;
alter publication supabase_realtime add table commesse;
alter publication supabase_realtime add table notifiche;
alter publication supabase_realtime add table timer_entries;

-- ============================================================
-- STORAGE BUCKETS
-- ============================================================
insert into storage.buckets (id, name, public) values ('documenti', 'documenti', false);
insert into storage.buckets (id, name, public) values ('foto', 'foto', false);

create policy "Authenticated upload docs" on storage.objects
  for insert with check (bucket_id in ('documenti', 'foto') and auth.role() = 'authenticated');

create policy "Authenticated read docs" on storage.objects
  for select using (bucket_id in ('documenti', 'foto') and auth.role() = 'authenticated');
