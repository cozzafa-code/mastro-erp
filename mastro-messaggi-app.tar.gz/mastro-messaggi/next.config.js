/** @type {import('next').NextConfig} */
const nextConfig = {
  // PWA-ready headers
  async headers() {
    return [{ source: '/(.*)', headers: [{ key: 'X-Content-Type-Options', value: 'nosniff' }] }]
  },
}
module.exports = nextConfig
