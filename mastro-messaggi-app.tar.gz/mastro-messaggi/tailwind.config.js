/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./app/**/*.{js,jsx}', './components/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        mastro: {
          dark: '#1A1C1E',
          bg: '#F8F8FA',
          gray: '#8E8E93',
          line: '#E5E5EA',
          blue: '#007AFF',
          red: '#FF3B30',
          orange: '#FF9500',
          green: '#34C759',
          purple: '#AF52DE',
          teal: '#5AC8FA',
          pink: '#FF2D55',
          amber: '#EAB308',
        },
      },
      fontFamily: {
        mono: ['SF Mono', 'Menlo', 'Consolas', 'monospace'],
      },
    },
  },
  plugins: [],
}
