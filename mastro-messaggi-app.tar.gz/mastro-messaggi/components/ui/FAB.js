'use client'
export default function FAB() { return <div>FAB</div> }
