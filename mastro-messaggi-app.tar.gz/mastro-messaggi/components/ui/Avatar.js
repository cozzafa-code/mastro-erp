'use client'
export default function Avatar() { return <div>Avatar</div> }
