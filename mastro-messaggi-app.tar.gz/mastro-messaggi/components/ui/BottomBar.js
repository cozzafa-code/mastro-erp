'use client'
export default function BottomBar() { return <div>BottomBar</div> }
