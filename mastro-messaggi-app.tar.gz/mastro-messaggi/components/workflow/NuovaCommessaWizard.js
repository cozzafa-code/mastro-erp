'use client'
export default function NuovaCommessaWizard({ onClose }) { return <div>Wizard</div> }
