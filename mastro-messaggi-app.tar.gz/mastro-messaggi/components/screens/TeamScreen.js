'use client'
export default function TeamScreen(props) { return <div>TeamScreen</div> }
