'use client'
export default function MessaggiScreen(props) { return <div>MessaggiScreen</div> }
