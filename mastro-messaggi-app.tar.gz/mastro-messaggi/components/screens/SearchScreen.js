'use client'
export default function SearchScreen(props) { return <div>SearchScreen</div> }
