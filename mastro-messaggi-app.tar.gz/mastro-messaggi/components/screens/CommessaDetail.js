'use client'
export default function CommessaDetail(props) { return <div>CommessaDetail</div> }
