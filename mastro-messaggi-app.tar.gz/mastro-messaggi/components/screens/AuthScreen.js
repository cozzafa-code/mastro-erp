'use client'
export default function AuthScreen(props) { return <div>AuthScreen</div> }
