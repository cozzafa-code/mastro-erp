'use client'
export default function SettingsScreen(props) { return <div>SettingsScreen</div> }
