# MASTRO messaggi

**Il workflow che parla. Lo stato che si muove.**

Sistema operativo serramentista — gestione commesse, team, timer, documenti con workflow a 11 fasi.

## Quick Start

### 1. Setup Supabase

1. Crea un progetto su [supabase.com](https://supabase.com)
2. Vai in **SQL Editor** e incolla il contenuto di `supabase/schema.sql` → **Run**
3. Poi incolla `supabase/seed.sql` → **Run** (dati Walter Cozza Serramenti)
4. Vai in **Settings > API** e copia URL e anon key

### 2. Setup progetto

```bash
cd mastro-messaggi
cp .env.example .env.local
# Compila .env.local con URL e KEY da Supabase

npm install
npm run dev
```

Apri [http://localhost:3000](http://localhost:3000)

### 3. Auth

Crea utenti in Supabase **Authentication > Users** e poi collega ogni utente a un `team_members` tramite `auth_user_id`.

## Struttura progetto

```
mastro-messaggi/
├── app/
│   ├── layout.js          # Root layout
│   ├── page.js            # Main page con routing
│   └── globals.css        # Design tokens MASTRO
├── components/
│   ├── ui/                # Header, BottomBar, FAB, Avatar
│   ├── screens/           # HomeScreen, CommesseScreen, etc.
│   └── workflow/          # NuovaCommessaWizard, PipelineView
├── lib/
│   ├── supabase.js        # Client Supabase
│   └── store.js           # Zustand store globale
├── supabase/
│   ├── schema.sql         # Database schema completo
│   └── seed.sql           # Dati iniziali Walter Cozza
└── public/
```

## Database Schema

### Tabelle principali:
- **azienda** — dati azienda (multi-tenant ready)
- **team_members** — operatori (Fabio, Roberto, Francesca...)
- **rappresentanti** — rete commerciale con provvigioni
- **fasi** — 11 fasi workflow configurabili
- **commesse** — cuore del sistema
- **commessa_chat** — messaggi real-time
- **commessa_log** — passaggi di fase (il messaggio È lo stato)
- **timer_entries** — tracciamento tempo per fase/sotto-fase
- **notifiche** — push verso team e rete

### Real-time enabled:
- `commessa_chat` — messaggi istantanei
- `commesse` — aggiornamenti stato
- `notifiche` — notifiche push
- `timer_entries` — timer sincronizzati

### RLS (Row Level Security):
Ogni tabella è protetta. Ogni utente vede solo i dati della sua azienda.

## Store (Zustand)

`lib/store.js` contiene TUTTO lo stato e le azioni:

```js
// Dati
useStore().commesse     // tutte le commesse
useStore().fasi         // workflow fasi
useStore().team         // membri team
useStore().notifiche    // notifiche

// Azioni
useStore().creaCommessa({...})
useStore().avanzaFase(commessaId, messaggio, docs)
useStore().tornaFase(commessaId, motivo)
useStore().bloccaCommessa(commessaId, motivo, tipo)
useStore().inviaMessaggio(commessaId, testo, allegato)
useStore().startTimer(commessaId, faseId, sottoFaseId)
useStore().stopTimer()
```

## Prototipo UI

Il file `mastro-messaggi.jsx` (2053 righe) contiene il prototipo completo come React artifact. Ogni componente in `components/` deve essere portato dal prototipo al componente reale.

**Mappa prototipo → componenti:**

| Prototipo | Componente reale |
|-----------|-----------------|
| `HomeScreen` | `components/screens/HomeScreen.js` |
| `InboxScreen` | `components/screens/CommesseScreen.js` |
| `CalendarioScreen` | `components/screens/CalendarioScreen.js` |
| `CommessaDetail` | `components/screens/CommessaDetail.js` |
| `PipelineView` | `components/workflow/PipelineView.js` |
| `NuovaCommessaWizard` | `components/workflow/NuovaCommessaWizard.js` |
| `TeamScreen` | `components/screens/TeamScreen.js` |
| `SettingsScreen` | `components/screens/SettingsScreen.js` |
| `FAB` | `components/ui/FAB.js` |
| `BottomBar` | `components/ui/BottomBar.js` |

## Ecosistema MASTRO

```
MASTRO MISURE → misure → MASTRO MESSAGGI → stato → MASTRO RETE
     (campo)              (laboratorio)           (rappresentante)
```

- **MESSAGGI** è il centro: gestisce commesse, workflow, timer, documenti
- **MISURE** alimenta le commesse con sorgente "misure"
- **RETE** riceve in sola lettura lo stato delle commesse del rappresentante

## Fasi Workflow

1. 📐 Misure (Fabio)
2. 📋 Preventivo (Roberto)
3. ⏳ Attesa cliente (Roberto)
4. ✅ Conferma ordine (Roberto)
5. 🧾 Fattura acconto (Francesca)
6. 💳 Pagamento (Francesca)
7. 📦 Ordine materiali (Antonio)
8. 🏭 Attesa materiali (Giuseppe)
9. 🔧 Produzione — 12 sotto-fasi (Marco)
10. 🏗️ Montaggio — 12 sotto-fasi (Pino)
11. 🏁 Chiusura cantiere (Fabio)

## Deploy

```bash
# Vercel (consigliato)
npx vercel

# Oppure build statica
npm run build
npm start
```

## Stack

- **Next.js 14** — App Router, SSR
- **Supabase** — Database, Auth, Realtime, Storage
- **Zustand** — State management
- **Vercel** — Deploy
- **Tailwind CSS** — Styling

---

*Walter Cozza Serramenti SRL — Costruttore di Sistemi AI Verticali per PMI*
