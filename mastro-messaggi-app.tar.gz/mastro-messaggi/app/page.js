'use client'
import { useEffect } from 'react'
import { useStore } from '@/lib/store'
import { getSupabase } from '@/lib/supabase'

// Screens
import Header from '@/components/ui/Header'
import BottomBar from '@/components/ui/BottomBar'
import FAB from '@/components/ui/FAB'
import HomeScreen from '@/components/screens/HomeScreen'
import CommesseScreen from '@/components/screens/CommesseScreen'
import CalendarioScreen from '@/components/screens/CalendarioScreen'
import MessaggiScreen from '@/components/screens/MessaggiScreen'
import TeamScreen from '@/components/screens/TeamScreen'
import SettingsScreen from '@/components/screens/SettingsScreen'
import CommessaDetail from '@/components/screens/CommessaDetail'
import NuovaCommessaWizard from '@/components/workflow/NuovaCommessaWizard'
import SearchScreen from '@/components/screens/SearchScreen'
import AuthScreen from '@/components/screens/AuthScreen'

export default function Page() {
  const { 
    user, loading, init, tab, detail, wizard, search,
    setDetail, setWizard, setSearch, setTab,
    timerRunning, tickTimer,
  } = useStore()
  
  // Init app
  useEffect(() => { init() }, [])
  
  // Timer tick ogni secondo
  useEffect(() => {
    if (!timerRunning) return
    const iv = setInterval(tickTimer, 1000)
    return () => clearInterval(iv)
  }, [timerRunning])
  
  // Loading
  if (loading) return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh', background: '#1A1C1E' }}>
      <div style={{ textAlign: 'center' }}>
        <div style={{ width: 60, height: 60, borderRadius: 14, background: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 12px' }}>
          <span style={{ fontSize: 36, fontWeight: 900, fontFamily: 'Georgia,serif', color: '#1A1C1E' }}>M</span>
        </div>
        <div style={{ fontSize: 10, fontWeight: 800, color: '#fff', letterSpacing: 3 }}>MASTRO</div>
        <div style={{ fontSize: 14, fontWeight: 300, color: '#8E8E93', marginTop: 2 }}>messaggi</div>
      </div>
    </div>
  )
  
  // Auth
  if (!user) return <AuthScreen />
  
  const shell = {
    maxWidth: 430, margin: '0 auto', minHeight: '100vh',
    fontFamily: "-apple-system,BlinkMacSystemFont,'SF Pro Display',sans-serif",
    background: '#F8F8FA', position: 'relative',
  }
  
  // Detail view
  if (detail) return (
    <div style={shell}>
      <CommessaDetail commessa={detail} onBack={() => setDetail(null)} />
    </div>
  )
  
  // Wizard
  if (wizard) return (
    <div style={shell}>
      <NuovaCommessaWizard onClose={() => setWizard(false)} />
    </div>
  )
  
  // Search
  if (search) return (
    <div style={shell}>
      <SearchScreen onClose={() => setSearch(false)} />
    </div>
  )
  
  // Main app
  return (
    <div style={shell}>
      <Header />
      
      <div style={{ paddingBottom: 70 }}>
        {tab === 'home' && <HomeScreen />}
        {tab === 'inbox' && <CommesseScreen />}
        {tab === 'calendario' && <CalendarioScreen />}
        {tab === 'messaggi' && <MessaggiScreen />}
        {tab === 'team' && <TeamScreen />}
        {tab === 'settings' && <SettingsScreen />}
      </div>
      
      {tab !== 'settings' && <FAB />}
      <BottomBar />
    </div>
  )
}
