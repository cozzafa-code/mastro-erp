import './globals.css'

export const metadata = {
  title: 'MASTRO messaggi',
  description: 'Il workflow che parla. Lo stato che si muove.',
  manifest: '/manifest.json',
  themeColor: '#1A1C1E',
  viewport: 'width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover',
}

export default function RootLayout({ children }) {
  return (
    <html lang="it">
      <body style={{ margin: 0, background: '#F8F8FA' }}>
        {children}
      </body>
    </html>
  )
}
